# Configuração de Admin - nos6@aluno.ifal.edu.br

## Instruções para Promover o Novo Admin

Este arquivo documenta como promover a conta `nos6@aluno.ifal.edu.br` para admin.

### Método 1: Via Painel Admin (Recomendado)

1. Faça login com uma conta admin existente
2. Vá para **Admin → Gerenciar Admins**
3. Clique em **Adicionar Admin**
4. Digite o email: `nos6@aluno.ifal.edu.br`
5. Clique em **Confirmar**

### Método 2: Via SQL Direto (Para Render)

Se você já tiver a conta criada no banco, execute este SQL:

```sql
UPDATE users 
SET role = 'admin' 
WHERE email = 'nos6@aluno.ifal.edu.br';
```

### Método 3: Via Script (Desenvolvimento Local)

```bash
# Primeiro, faça login com a conta nos6@aluno.ifal.edu.br para criar o usuário
# Depois, execute:
mysql -u root -p warden_shop < add-admin.sql
```

## Próximos Passos

1. A conta `nos6@aluno.ifal.edu.br` fará login pela primeira vez
2. Após o login, execute o SQL acima para promover para admin
3. Faça logout e login novamente para ver o painel admin

## Informações da Conta

- **Email**: nos6@aluno.ifal.edu.br
- **Papel**: Admin
- **Permissões**: Acesso total ao painel administrativo
