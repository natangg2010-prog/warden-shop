-- Adicionar novo admin nos6@aluno.ifal.edu.br
INSERT INTO users (openId, name, email, loginMethod, role, createdAt, updatedAt, lastSignedIn)
VALUES (
  CONCAT('nos6_', DATE_FORMAT(NOW(), '%Y%m%d%H%i%s')),
  'Admin nos6',
  'nos6@aluno.ifal.edu.br',
  'email',
  'admin',
  NOW(),
  NOW(),
  NOW()
)
ON DUPLICATE KEY UPDATE role = 'admin', updatedAt = NOW();
