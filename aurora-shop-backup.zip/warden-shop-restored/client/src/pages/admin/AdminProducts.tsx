import { trpc } from "@/lib/trpc";
import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Loader2, Plus, Pencil, Trash2, Package } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

type ProductForm = {
  categoryId: string;
  name: string;
  description: string;
  kitContents: string;
  price: string;
  stock: string;
  imageUrl: string;
  commands: string;
  active: boolean;
};

const emptyForm: ProductForm = {
  categoryId: "",
  name: "",
  description: "",
  kitContents: "",
  price: "",
  stock: "-1",
  imageUrl: "",
  commands: "",
  active: true,
};

export default function AdminProducts() {
  const utils = trpc.useUtils();
  const { data: products, isLoading } = trpc.admin.getProducts.useQuery();
  const { data: categories } = trpc.admin.getCategories.useQuery();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<ProductForm>(emptyForm);

  const createProduct = trpc.admin.createProduct.useMutation({
    onSuccess: () => {
      utils.admin.getProducts.invalidate();
      utils.admin.getDashboard.invalidate();
      setDialogOpen(false);
      toast.success("Produto criado!");
    },
    onError: (e) => toast.error(e.message),
  });

  const updateProduct = trpc.admin.updateProduct.useMutation({
    onSuccess: () => {
      utils.admin.getProducts.invalidate();
      setDialogOpen(false);
      toast.success("Produto atualizado!");
    },
    onError: (e) => toast.error(e.message),
  });

  const deleteProduct = trpc.admin.deleteProduct.useMutation({
    onSuccess: () => {
      utils.admin.getProducts.invalidate();
      utils.admin.getDashboard.invalidate();
      toast.success("Produto removido.");
    },
  });

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setDialogOpen(true);
  };

  const openEdit = (p: NonNullable<typeof products>[0]) => {
    setEditingId(p.id);
    const kitArr: string[] = (() => {
      try { return p.kitContents ? JSON.parse(p.kitContents) : []; } catch { return []; }
    })();
    const cmdArr: string[] = (() => {
      try { return p.commands ? JSON.parse(p.commands) : []; } catch { return []; }
    })();
    setForm({
      categoryId: String(p.categoryId),
      name: p.name,
      description: p.description ?? "",
      kitContents: kitArr.join("\n"),
      price: String(p.price),
      stock: String(p.stock),
      imageUrl: p.imageUrl ?? "",
      commands: cmdArr.join("\n"),
      active: p.active,
    });
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const kitContentsJson = form.kitContents.trim()
      ? JSON.stringify(form.kitContents.split("\n").map((s) => s.trim()).filter(Boolean))
      : undefined;
    const commandsJson = form.commands.trim()
      ? JSON.stringify(form.commands.split("\n").map((s) => s.trim()).filter(Boolean))
      : undefined;

    if (editingId) {
      updateProduct.mutate({
        id: editingId,
        categoryId: parseInt(form.categoryId),
        name: form.name,
        description: form.description || undefined,
        kitContents: kitContentsJson,
        price: form.price,
        stock: parseInt(form.stock),
        imageUrl: form.imageUrl || undefined,
        commands: commandsJson,
        active: form.active,
      });
    } else {
      createProduct.mutate({
        categoryId: parseInt(form.categoryId),
        name: form.name,
        description: form.description || undefined,
        kitContents: kitContentsJson,
        price: form.price,
        stock: parseInt(form.stock),
        imageUrl: form.imageUrl || undefined,
        commands: commandsJson,
        active: form.active,
      });
    }
  };

  const formatPrice = (v: string | number) =>
    `R$ ${parseFloat(String(v)).toFixed(2).replace(".", ",")}`;

  return (
    <AdminLayout title="Produtos">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Produtos
          </h2>
          <Button onClick={openCreate} className="gap-2">
            <Plus className="h-4 w-4" /> Novo
          </Button>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-40">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-2">
            {products?.map((product) => (
              <div
                key={product.id}
                className="flex items-center gap-4 p-4 rounded-lg bg-card border border-border"
              >
                <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  {product.imageUrl ? (
                    <img src={product.imageUrl} alt={product.name} className="h-full w-full object-cover rounded-lg" />
                  ) : (
                    <Package className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-foreground truncate">{product.name}</p>
                    {!product.active && (
                      <Badge variant="outline" className="text-xs text-muted-foreground">Inativo</Badge>
                    )}
                  </div>
                  <p className="text-sm text-primary font-bold">{formatPrice(product.price)}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => openEdit(product)}>
                    <Pencil className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive hover:text-destructive"
                    onClick={() => {
                      if (confirm("Remover produto?")) deleteProduct.mutate({ id: product.id });
                    }}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-card border-border max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-foreground">
              {editingId ? "Editar Produto" : "Novo Produto"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="text-foreground mb-1.5 block">Categoria *</Label>
              <Select value={form.categoryId} onValueChange={(v) => setForm({ ...form, categoryId: v })}>
                <SelectTrigger className="bg-muted border-border">
                  <SelectValue placeholder="Selecione..." />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {categories?.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-foreground mb-1.5 block">Nome *</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="bg-muted border-border"
                required
              />
            </div>
            <div>
              <Label className="text-foreground mb-1.5 block">Descrição</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="bg-muted border-border resize-none"
                rows={3}
              />
            </div>
            <div>
              <Label className="text-foreground mb-1.5 block">
                Conteúdo do Kit (um item por linha)
              </Label>
              <Textarea
                value={form.kitContents}
                onChange={(e) => setForm({ ...form, kitContents: e.target.value })}
                className="bg-muted border-border resize-none font-mono text-sm"
                rows={4}
                placeholder={"Espada de ferro\n32x Pão\n5x Poção de Cura"}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-foreground mb-1.5 block">Preço (R$) *</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  className="bg-muted border-border"
                  required
                />
              </div>
              <div>
                <Label className="text-foreground mb-1.5 block">Estoque (-1 = ilimitado)</Label>
                <Input
                  type="number"
                  value={form.stock}
                  onChange={(e) => setForm({ ...form, stock: e.target.value })}
                  className="bg-muted border-border"
                />
              </div>
            </div>
            <div>
              <Label className="text-foreground mb-1.5 block">URL da Imagem</Label>
              <Input
                value={form.imageUrl}
                onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
                className="bg-muted border-border"
                placeholder="https://..."
              />
            </div>
            <div>
              <Label className="text-foreground mb-1.5 block">Comandos Minecraft (um por linha)</Label>
              <Textarea
                value={form.commands}
                onChange={(e) => setForm({ ...form, commands: e.target.value })}
                className="bg-muted border-border resize-none font-mono text-xs"
                rows={3}
                placeholder={'/execute as {player} at @s run structure load kitdima ~ ~ ~\n/give {player} diamond_sword\n/effect {player} speed 300 2'}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Use {'{player}'} para substituir pelo nickname do jogador
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={form.active}
                onCheckedChange={(v) => setForm({ ...form, active: v })}
              />
              <Label className="text-foreground">Produto ativo</Label>
            </div>
            <div className="flex gap-2 pt-2">
              <Button type="submit" disabled={createProduct.isPending || updateProduct.isPending} className="flex-1">
                {(createProduct.isPending || updateProduct.isPending) && (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                )}
                {editingId ? "Salvar" : "Criar Produto"}
              </Button>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
